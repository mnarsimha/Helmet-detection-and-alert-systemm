import winsound
import cv2
import numpy as np
import winsound
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

yolo = cv2.dnn.readNet("yolov4-custom.cfg","yolov4-custom_best.weights")
cap =cv2.VideoCapture(0)

classes =[]
with open("./obj.names","r") as f:
    classes =f.read().splitlines()

def send_mail():
     #add mail code here
        fromaddr = "sendermail@gmail.com"
        toaddr = "recivermail@gmail.com"
        msg = MIMEMultipart()
        msg['From'] = fromaddr
        msg['To'] = toaddr
        msg['Subject'] = "Helmet is not detected"

        body = "Lve you Sanath"

        
        msg.attach(MIMEText(body, 'plain'))

        #filename = "File_name_with_extension"
        #attachment = open("Path of the file", "rb")

       
        p = MIMEBase('application', 'octet-stream')

        # To change the payload into encoded form
        #p.set_payload((attachment).read())

        # encode into base64
        #encoders.encode_base64(p)

        #p.add_header('Content-Disposition', "attachment; filename= %s" % filename)

        # attach the instance 'p' to instance 'msg'
        #msg.attach(p)

        # creates SMTP session
        s = smtplib.SMTP('smtp.gmail.com', 587)

        # start TLS for security
        s.starttls()

        # Authentication
        s.login(fromaddr, "ahhommgoilorwvwm")

        # Converts the Multipart msg into a string
        text = msg.as_string()

        # sending the mail
        s.sendmail(fromaddr, toaddr, text)

        # terminating the session
        s.quit()
flag = True
cnt = 1
while True:
    _,img = cap.read()
    height,width,_=img.shape
    blob =cv2.dnn.blobFromImage(img,1/255,(416,416),(0,0,0),swapRB=True,crop=False)
    yolo.setInput(blob)
    op_layer = yolo.getUnconnectedOutLayersNames()
    layer_op = yolo.forward(op_layer)
   
    boxes =[]
    confidences =[]
    class_ids =[]

    for op in layer_op:
        for det in op:
            score = det[5:]
            class_id = np.argmax(score)
            confidence = score[class_id]
            if confidence > 0.7:
                c_x= int(det[0]*width)
                c_y= int(det[0]*height)
                w= int(det[0]*width)
                h= int(det[0]*height)
                x=int(c_x-w/2)
                y=int(c_y-h/2)
                boxes.append([x,y,w,h])
                confidences.append(float(confidence))
                class_ids.append(class_id)

    indexes = cv2.dnn.NMSBoxes(boxes,confidences,0.5,0.4)
    font  = cv2.FONT_HERSHEY_PLAIN
    colors = np.random.uniform(0,255,size =(len(boxes),3))
    #img = cv2.resize(img,(320,320),interpolation=cv2.INTER_AREA)
    if len(boxes)>0:
        for i in indexes.flatten():
            x,y,w,h = boxes[i]
            label = str(classes[class_ids[i]])
            con = str(confidences[i])
            col = colors[i]
            cv2.rectangle(img,(x,y),(x+w,y+h),col,2)
            cv2.putText(img,label+" "+con,(x,y+20),font,2,(255,255,255),1)
    else:
        winsound.Beep(2500,1000)
        flag = False
        if flag == False and cnt == 1:
            send_mail()
        cnt += 1 
     

    
    cv2.imshow("live",img)
    key=cv2.waitKey(1)
    if key==27:
        cap.release()
        cv2.destroyAllWindows()
        break




